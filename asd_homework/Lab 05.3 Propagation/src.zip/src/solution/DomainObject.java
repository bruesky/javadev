package solution;

public class DomainObject
{
}