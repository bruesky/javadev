package skeleton;

public class DomainObject
{
}