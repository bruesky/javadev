package solution;

public class Indicator {
    public String yellow(){
        return "indicator yellow";
    }

    public String green(){
        return "indicator green";
    }

    public String red(){
        return "indicator red";
    }

    public String blue(){
        return "indicator blue";
    }

    public String blink(){
        return "indicator blink";
    }
}
