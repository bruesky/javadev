package solution;

public enum StateEnum {
    SUSPENDED,PROJECTING,COOLINGOFF
}
