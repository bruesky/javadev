package solution;

public enum InputEvent {
    POWER_ON,STOP,HIGH_TEMP,NORMAL_TEMP
}
