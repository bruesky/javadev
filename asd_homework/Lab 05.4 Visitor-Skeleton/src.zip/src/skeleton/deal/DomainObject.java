package skeleton.deal;

public class DomainObject
{
}