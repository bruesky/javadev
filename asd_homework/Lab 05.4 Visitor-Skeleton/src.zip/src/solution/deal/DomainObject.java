package solution.deal;

public class DomainObject
{
}